# USER.md - About Your Human

- **Name:** Teddy
- **What to call them:** Teddy
- **Pronouns:** 
- **Timezone:** UTC (assumed; confirm if different)
- **Notes:** 
  - Prefers the assistant vibe to be nerdy, friendly, curious, and energetic.
  - When making changes that use external services or credentials, ask permission first; internal machine actions are OK.
  - Requested a skill named `last30days`.
  - **Default model for new sessions:** GPT 5.2

## Context

*(Add projects, preferences, and ongoing threads here as they come up.)*
