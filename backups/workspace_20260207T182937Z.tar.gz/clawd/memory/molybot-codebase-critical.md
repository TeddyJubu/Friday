# Molybot — Codebase & Runtime Critical Notes (Ops/Maintenance)

This repo (`/home/ubuntu/clawd`) is the **Clawdbot workspace** used by the running agent(s). Molybot is a **WooCommerce ops agent** that should operate **only on allowlisted WhatsApp senders and allowlisted WP sites**, primarily via **SSH → WP-CLI**.

## 0) “Source of truth” map (what lives where)
- **Workspace (this repo):** `/home/ubuntu/clawd`
  - Human-editable operational files live in `memory/`.
  - SSH keys for WP-CLI/SSH live in `keys/`.
  - Skills live in `skills/` (includes WordPress MCP guidance).
- **Gateway runtime config (NOT in this repo):** `~/.clawdbot/clawdbot.json`
  - This is where **WhatsApp channel accounts**, **bindings/routing to agents**, and **tool policies** are actually enforced.
  - Apply changes via gateway config commands (then restart gateway), not by editing workspace files.

## 1) Molybot operational config in this workspace
These files define what Molybot is allowed to do and where:

### Access allowlist (deny-by-default)
- `memory/molybot-allowlist.json`
  - `mode`: `deny_by_default`
  - `allowed_numbers`: who can command Molybot via WhatsApp.
  - Keep this tight; add/remove numbers here when granting/revoking access.

### Site inventory / connection profiles
- `memory/molybot-sites.json`
  - Maps a site key → label/baseUrl + SSH connection + WP path.
  - Current site:
    - `uniquecollectionbyprincess` (Unique Collection by Princess)
    - SSH user/host/port + WP install path: `public_html`
    - SSH key is referenced by path (no passwords stored).

### SOP / approval gates (two-phase commit)
- `memory/molybot-sop.md`
  - **Approval required** (always): refunds, deletes, price changes, bulk ops >5 items, payment/shipping/tax setting changes.
  - Workflow: propose exact commands → generate `APPROVE-XXXX` → execute only after matching code.

### Audit trail
- `memory/molybot-audit-YYYY-MM.md` (example present: `memory/molybot-audit-2026-02.md`)
  - Append an audit line for every execution: timestamp, requester, site, action, commands, result.

### Quick reference / “essential memory”
- `memory/molybot-memory.md`
  - Consolidates the above (role, site, SSH command pattern, rules).

## 2) SSH keys & permissions (don’t break this)
- Keys are stored at:
  - `/home/ubuntu/clawd/keys/molybot/id_ed25519` (mode `600`)
  - `/home/ubuntu/clawd/keys/molybot/id_ed25519.pub`
- Expected WP-CLI execution pattern (example):
  - `ssh -i /home/ubuntu/clawd/keys/molybot/id_ed25519 -p <port> <user>@<host> "wp --path=public_html <command>"`

Operational note: prefer read-only WP-CLI queries first; apply smallest change; verify after.

## 3) WordPress / WooCommerce tooling in repo
- Skill: `skills/wordpress-mcp-pro/`
  - `SKILL.md`: operational WP-CLI workflow + MCP connection options.
  - `scripts/wpcli_install.sh`: installs WP-CLI when needed.
  - References: `references/wp-cli.md`, `references/wordpress-mcp.md`.

Molybot’s primary path is still **SSH → WP-CLI**; MCP is optional if you later want HTTP-based structured access.

## 4) WhatsApp accounts, routing/bindings, and agent identities (runtime)
This workspace contains **conversation logs** under `memory/` (e.g., `memory/2026-01-28-*-whatsapp-*.md`), but the **real WhatsApp configuration** is in `~/.clawdbot/clawdbot.json`.

What to look for / maintain in `clawdbot.json`:
- `channels.whatsapp`:
  - accounts (if multiple WhatsApp identities are used)
  - auth directories (where the WhatsApp session credentials live)
  - inbound allow/deny rules (often an `allowFrom`-style list)
- `agents`:
  - `agents.defaults` for global behavior
  - `agents.list[]` for a dedicated Molybot agent profile (`id: "molybot"`, identity, workspace, tool allow/deny)
- `bindings[]`:
  - routes inbound messages to agents by matching channel/account/chat/group etc.
  - recommended: bind a dedicated WhatsApp account (or group) → `agentId: "molybot"`

Practical: Molybot should have **agent-specific tool allow/deny** so it can’t use unrelated tools even if global tools are powerful.

## 5) Tool policy / safety posture (runtime)
Repository-side SOPs exist (above), but enforcement is strongest when done in gateway config:
- Prefer **agent-scoped** tool policy: `agents.list[].tools.allow` / `tools.deny`.
  - Typical Molybot allow: `read`, `exec` (and maybe `write` for audit files), optionally `browser`.
  - Typical deny: `message` (if you do not want proactive outbound), `nodes`, etc.
- If exec is broadly enabled globally, compensate by:
  - limiting Molybot’s `exec` to specific commands/hosts (if supported), and/or
  - requiring approvals for risky exec operations (if your gateway supports `approvals.exec` per-agent).

## 6) Sessions & sub-agents (how work gets delegated)
- Each chat runs in a **session** (examples in logs show `Session Key` like `agent:main:main` or group-specific keys).
- Sub-agents are separate sessions spawned by the main agent for focused work; they can be ephemeral or kept.
- Operational convention in this workspace (from `AGENTS.md`):
  - write continuity into files under `memory/` (daily notes + curated `MEMORY.md`).

## 7) Where to find “logs” in this repo
- Human-readable interaction summaries are kept as markdown files under `memory/` (dated session logs).
- Molybot’s own operational audit is `memory/molybot-audit-YYYY-MM.md`.

## 8) Quick maintenance checklist
- Add/remove permitted commanders: edit `memory/molybot-allowlist.json`.
- Add a new Woo site: add entry to `memory/molybot-sites.json` (SSH host/user/port/wpPath + keyPath).
- Keep SSH keys in `keys/molybot/` with strict permissions.
- Keep SOP rules current: `memory/molybot-sop.md`.
- Enforce guardrails in `~/.clawdbot/clawdbot.json` (agent tools + WhatsApp bindings), then restart gateway.
