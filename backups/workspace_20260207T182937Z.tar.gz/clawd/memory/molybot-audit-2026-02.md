# Molybot Audit Log — 2026-02

(append-only)

- 2026-02-02: Initialized Molybot session. Loaded allowlist (deny-by-default; allowed_numbers: +8801521207499). No operational changes executed.
- 2026-02-02: REQUEST (allowlisted +8801521207499): List last 10 orders with id, status, total, customer email. Provided WP-CLI commands only; no SSH executed.
- 2026-02-02: POLICY UPDATE: SSH key auth only. Use key /home/ubuntu/clawd/keys/molybot/id_ed25519 and SSH options -o BatchMode=yes; always include -i and never request password.
- 2026-02-02: REQUEST: Count products for uniquecollectionbyprincess.com. Denied/not executed due to allowlist (deny-by-default) and requester identity not provided/verified.
- 2026-02-02: POLICY UPDATE: Messages prefixed with /molybot and routed by main agent are treated as verified requester identity; only challenge if not allowlisted.
- 2026-02-02: POLICY UPDATE: Correct WP root path for uniquecollectionbyprincess.com is domains/uniquecollectionbyprincess.com/public_html (not ~/public_html).
- 2026-02-07: REQUEST (allowlisted +8801521207499): Installed/updated remote backup script for uniquecollectionbyprincess.com at ~/backups/ucbp/scripts/backup_ucbp.sh. Implemented DB dump fallback to mysqldump because `wp db export` exits 255 on this host. Verified successful run produced: db.sql (~7.3M), wp-content.tgz (~226M), plugins.csv, wp-core-version.txt. NOTE: Attempted to install cron via `crontab`, but `crontab` command is not available on the host; must schedule via hosting control panel (Hostinger/hPanel) or alternative scheduler.
- 2026-02-07: REQUEST (allowlisted +8801521207499): Uploaded WooCommerce product "Ramper Love Frock" (variable) with image ramper-love-frock.jpg, attribute Age (5-8 years, 9-14 years), variations priced 1200 and 1300, stock=made-to-order (in_stock=true, no stock mgmt). Created category "Kids Dresses" (under "Kids Clothing") and assigned product. Product ID 5255, variations 5256/5257, image attachment 5254, permalink https://uniquecollectionbyprincess.com/product/ramper-love-frock/
- 2026-02-07: REQUEST (allowlisted +8801521207499): Uploaded WooCommerce product "Eid premium gharara 1" (variable) with image eid-premium-gharara-1.jpg, attribute Age (2-4, 5-7, 8-9, 10-14), variations priced 1350/1400/1550/1600, stock=made-to-order (in_stock=true, no stock mgmt). Assigned category "Kids Dresses". Product ID 5259, variations 5260/5261/5262/5263, image attachment 5258, permalink https://uniquecollectionbyprincess.com/product/eid-premium-gharara-1/
